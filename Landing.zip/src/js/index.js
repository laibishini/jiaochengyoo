/**
 * Created by jne on 2017/10/14.
 */
var a = 1;var c=0;


window.onload = function(){
    console.log(2222222222)
}